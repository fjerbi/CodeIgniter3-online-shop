A Pen created at CodePen.io. You can find this one at https://codepen.io/YaswanthGupta/pen/jPgERw.

 This is a simple login page with each HTML element having its own 'id' or 'class' so that it is easily editable. If you like this, please share this with below link with your friends.
http://codepen.io/YaswanthGupta/full/jPgERw/