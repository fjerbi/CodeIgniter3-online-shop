A Pen created at CodePen.io. You can find this one at https://codepen.io/alexcarpenter/pen/LveDx.

 Using the :after element to add a gradient overlay to a background image.
Blog post: http://alexcarpenter.me/blog/2013/background-image-gradient-overlay