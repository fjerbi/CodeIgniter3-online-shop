$('.marquee').marquee({
	duration: 2000,
	gap: 1,
	delayBeforeStart: 0,
	direction: 'up',
	duplicated: false
});