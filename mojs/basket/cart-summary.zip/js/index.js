$(document).ready(function(){
$(".cart_btn").click(function(){
  $(".details").slideToggle(1000);
});
});